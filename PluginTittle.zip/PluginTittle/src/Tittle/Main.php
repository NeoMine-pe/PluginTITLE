<?php

declare(strict_types = 1);

namespace Tittle;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase {

    public function onEnable() : void {
        $this->title = new Config($this->getDataFolder() . "title.yml", Config::YAML);

    }
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        
            if ($command->getName() == "Tittle"); {
                $name = strtolower($sender->getName());
                if(!($sender instanceof Player)) {
                    $sender->sendMessage("Только в игре!");
                    return false;
                }        
                if (!isset($args[0])) {
                    $sender->sendMessage("§cИспользование: /tittle <Что вы хотите транслировать>");
                    return FALSE;
                }
                if ((time() - $this->title->get($name)) < 1200){
                    $sender->sendMessage("§f[§6+§f] §cВы можете отправить тайтл повторно через 10 минут!");
                return false;
                }

                if (!$sender->hasPermission("tittle.use")) {
                    $sender->sendMessage("Недостаточно прав!");
                    return false;
                }
                $this->title->set(strtolower($sender->getName()), time() - 600);
                $this->title->save();
                $this->getServer()->broadcastTitle($sender->getName(). " сообщает: ",implode(' ', $args));
                   return TRUE; 
            }      
    }
}

